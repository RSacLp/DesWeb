import { Component } from '@angular/core';

@Component({
  selector: 'app-error404-page',
  standalone: true,
  imports: [],
  templateUrl: './error404-page.component.html',
  styleUrl: './error404-page.component.css'
})
export class Error404PageComponent {

}
