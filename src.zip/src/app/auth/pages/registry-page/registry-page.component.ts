import { Component } from '@angular/core';

@Component({
  selector: 'app-registry-page',

  templateUrl: './registry-page.component.html',
  styleUrl: './registry-page.component.css'
})
export class RegistryPageComponent {

}
