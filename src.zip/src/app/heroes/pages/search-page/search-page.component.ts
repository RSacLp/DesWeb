import { Component } from '@angular/core';

@Component({
  selector: 'app-search-page',


  templateUrl: './search-page.component.html',
  styleUrl: './search-page.component.css'
})
export class SearchPageComponent {

}
